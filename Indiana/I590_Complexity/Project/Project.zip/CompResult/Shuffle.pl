open (INPUT, "SGD.OriginalGO.txt_SGD.info.txt.compfull");
open (OUTPUT, ">SGD.OriginalGO.New.txt");

while(<INPUT>)
{   chomp($line=$_);
    @tmpSplit= split (/\t/, $line);
    print OUTPUT $tmpSplit[10]."\t".$tmpSplit[11]."\t".$tmpSplit[12]."\t".
                 $tmpSplit[4]."\t".$tmpSplit[5]."\t".$tmpSplit[6]."\t".
                 $tmpSplit[7]."\t".$tmpSplit[8]."\n";

}   close OUTPUT;


open (INPUT, "SGD.FullGO.txt_SGD.info.txt.compfull");
open (OUTPUT, ">SGD.FullGO.New.txt");

while(<INPUT>)
{   chomp($line=$_);
    @tmpSplit= split (/\t/, $line);
    print OUTPUT $tmpSplit[10]."\t".$tmpSplit[11]."\t".$tmpSplit[12]."\t".
                 $tmpSplit[4]."\t".$tmpSplit[5]."\t".$tmpSplit[6]."\t".
                 $tmpSplit[7]."\t".$tmpSplit[8]."\n";

}   close OUTPUT;