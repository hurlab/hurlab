#! /usr/local/perl -w
# ------------------------------------------------------------------------------
#
#   Microarray_Data_Merging.pl
#
#                                              Written by Junguk Hur
#
#   * This script extract Microarray ratio data from three data files
#     according to the ABI gene IDs for specific target lists
#
# ------------------------------------------------------------------------------

use strict;
use warnings;

# ------------------------------------------------------------------------------
# Check directory existence
my $MicroArrayDir = "Microarray_Data";
my $TargetListDir = "Target_List";
my $ResultDir = "Result";
opendir (MICROARRAY,"./Microarray_Data") || die "Can't open \'Microarray_Data\'".
                                                " directory\n";
closedir (MICROARRAY);
opendir (TARGETLIST,"./Target_List") || die "Can't open \'Target_List\'".
                                                " directory\n";
my @targetFile = sort readdir(TARGETLIST);
shift @targetFile;   shift @targetFile;
closedir (TARGETLIST);

mkdir ("Result") || print "";

# ------------------------------------------------------------------------------
# Read Microarray Data Files
my $microDir="Microarray_Data";
my $targetDir="Target_List";

# 1. Agilent
open (AGILENT,"./$microDir/Agilent.txt") || die " Can't open Agilent.txt file\n";
# Only has AGI ID
# #Systematic        Normalized        t-test P-value        Description
my (%AgilentRatio_AGI,%AgilentDesc_AGI);
my @AgilentFileContent = <AGILENT>;
shift @AgilentFileContent;    # Remove the first element '# line
foreach my $line (@AgilentFileContent)
{   $line =~ s/\r|\n//g;
    my @tmp = split (/\t/,$line);
    $tmp[0] = uc ($tmp[0]);
    if (defined $AgilentRatio_AGI{$tmp[0]})
    {   print "Duplication AGI ID $tmp[0]\n";
    }else
    {   $AgilentRatio_AGI{$tmp[0]} = $tmp[1];
        $AgilentDesc_AGI{$tmp[0]} = $tmp[3];
    }
}   close AGILENT;


# 2. cDNA
open (CDNA,"./$microDir/cDNA.txt") || die " Can't open cDNA.txt file\n";
# Only has AGI ID
# #Systematic        Normalized        t-test P-value        Description
my (%AGI2GEN,%CDNARatio_GEN,%CDNADesc_GEN);
my @CDNAFileContent = <CDNA>;
shift @CDNAFileContent;    # Remove the first element '# line
foreach my $line (@CDNAFileContent)
{   $line =~ s/\r|\n//g;
    my @tmp = split (/\t/,$line);
    $tmp[0] = uc ($tmp[0]);
    $tmp[1] = uc ($tmp[1]);
    if ( defined $tmp[1] ne "")
    {   if (defined $AGI2GEN{$tmp[1]})
        {   $AGI2GEN{$tmp[1]} .= $tmp[0].';';
        }else
        {   $AGI2GEN{$tmp[1]} = $tmp[0].';';
        }
        $CDNARatio_GEN{$tmp[0]} = $tmp[2];
        $CDNADesc_GEN{$tmp[0]} = $tmp[3];
    }
}   close CDNA;


# 3. Affy
open (AFFY,"./$microDir/Affy.txt") || die " Can't open Affy.txt file\n";
# Only has AGI ID
# #Systematic        Normalized        t-test P-value        Description
my (%AffyRatio1_AGI,%AffyRatio2_AGI, %AffyDesc_AGI);
my @AFFYFileContent = <AFFY>;
shift @CDNAFileContent;    # Remove the first element '# line
foreach my $line (@AFFYFileContent)
{   $line =~ s/\r|\n//g;
    my @tmp = split (/\t/,$line);
    $tmp[1] = uc ($tmp[1]);
    if ( defined $tmp[1] ne "")
    {   $AffyRatio1_AGI{$tmp[1]} = $tmp[2];
        $AffyRatio2_AGI{$tmp[1]} = $tmp[4];
        $AffyDesc_AGI{$tmp[1]} = $tmp[6];
    }
}   close AFFY;



# ------------------------------------------------------------------------------
foreach my $fileName (@targetFile)
{   open (FILE,$TargetListDir."/".$fileName);
    open (RESULT,">$ResultDir/$fileName"."_Result.txt");

    my @fileCont = <FILE>;
    my $Array1 = "";   my $Array2 = "";
    $fileCont[0] =~ s/\r|\n//g;
    my @tmp = split (/\t/, $fileCont[0]);
    shift @fileCont;
    $Array1 = $tmp[1]; $Array2 = $tmp[2];
    if (($Array1 eq 'cDNA') || ($Array2 eq 'cDNA'))
    {   if ($Array2 eq 'cDNA')
        {   $Array2 = $Array1;   $Array1 = 'cDNA';
        }
        print RESULT "#AGI\tGenBank\tcDNA\t";
        if ($Array2 eq 'Affy')
        {   print RESULT "Affy_ABI5\tAffy_WT\tDesc\n";
        }else
        {   print RESULT "Agilent\tDesc\n";
        }
        foreach my $newLine (@fileCont)
        {   $newLine =~ s/\r|\n//g;
            my @tmpSplit = split (/\t/, $newLine);
            my $agiID = uc ($tmpSplit[0]);
            if (defined $AGI2GEN{$agiID})
            {   my @GENtmp = split (/\;/, $AGI2GEN{$agiID});
                foreach (@GENtmp)
                {   print RESULT $agiID."\t".$_."\t".$CDNARatio_GEN{$_}."\t";

                    if (($Array2 eq 'Affy') && (defined $AffyRatio1_AGI{$agiID}))
                    {   print RESULT $AffyRatio1_AGI{$agiID}."\t".
                                     $AffyRatio2_AGI{$agiID}."\t".
                                     $AffyDesc_AGI{$agiID}."\n";
                    }elsif (($Array2 eq 'Agilent') && (defined $AgilentRatio_AGI{$agiID}))
                    {   print RESULT $AgilentRatio_AGI{$agiID}."\t".
                                     $AgilentDesc_AGI{$agiID}."\n";
                    }else
                    {   print RESULT "\t\t\n";
                    }
                }
            }else
            {   print RESULT $agiID."\t\t";
                if (($Array2 eq 'Affy') && (defined $AffyRatio1_AGI{$agiID}))
                {   print RESULT $AffyRatio1_AGI{$agiID}."\t".
                                 $AffyRatio2_AGI{$agiID}."\n";
                }elsif (($Array2 eq 'Agilent') && (defined $AgilentRatio_AGI{$agiID}))
                {   print RESULT $AgilentRatio_AGI{$agiID}."\n";
                }else
                {   print RESULT "\t\t\n";
                }
            }
        }
    }else   # if there is no cDNA needed. Only Agilent and Affy
    {   print RESULT "#AGI\tAgilent\tAffy_ABI5\tAffy_WT\tDesc\n";
        foreach my $newLine (@fileCont)
        {   $newLine =~ s/\r|\n//g;
            my @tmpSplit = split (/\t/, $newLine);
            my $agiID = uc ($tmpSplit[0]);
            if (defined $AgilentRatio_AGI{$agiID})
            {   print RESULT $agiID."\t".$AgilentRatio_AGI{$agiID}."\t";
                if (defined $AffyRatio1_AGI{$agiID})
                {   print RESULT $AffyRatio1_AGI{$agiID}."\t".
                                 $AffyRatio2_AGI{$agiID}."\t".
                                 $AffyDesc_AGI{$agiID}."\n";
                }else
                {   print RESULT "\t\t$AgilentDesc_AGI{$agiID}\n";
                }
            }else
            {   print RESULT $agiID."\t\t";
                if (defined $AffyRatio1_AGI{$agiID})
                {   print RESULT $AffyRatio1_AGI{$agiID}."\t".
                                 $AffyRatio2_AGI{$agiID}."\t".
                                 $AffyDesc_AGI{$agiID}."\n";
                }else
                {   print RESULT "\t\n";
                }
            }
        }
    }
}